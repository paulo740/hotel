import os
from flask import Flask, send_from_directory
import openpyxl
from datetime import(
    datetime
)
 

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

FRONT_DIR = os.path.join(BASE_DIR, "front end")

STATIC_DIR = os.path.join(BASE_DIR, "static")

DB_DIR =  os.path.join(os.path.dirname(__file__), "..","db")
EXCEL_FILE = os.path.join(DB_DIR, "clientes.xlsx")

COLUMNS = [
    "ID",
    "NOME",
    "CPF",
    "EMAIL",
    "TELEFONE",
    "ENDEREÇO",
    "OBSERVAÇÕES",
    "DATA CADASTRO",

]

def init_excel():
    if not os.path.exists(DB_DIR): 
        os.makedirs(DB_DIR)

    if not os.path.exists(EXCEL_FILE):
        workbook = openpyxl.Workbook()
        sheet= workbook.active
        sheet.title = "clientes"
        sheet.append(COLUMNS)
        workbook.save(EXCEL_FILE)

app = Flask(__name__, static_folder=STATIC_DIR,static_url_path="/" + STATIC_DIR) 

@app.route('/')
def home():
    return send_from_directory(FRONT_DIR, "index.html")



@app.route('/consulta')
def consulta_page():
    return send_from_directory(FRONT_DIR, "consulta.html")




@app.route('/alterar')
def alterar_page():
    return send_from_directory(FRONT_DIR, "alterar.html")


if __name__=="__main__":
    print("BASE_DIR:", BASE_DIR)
    print("FRONTEND_DIR:", FRONT_DIR)
    print("STATIC_DIR:", STATIC_DIR)
    app.run(debug=True)

